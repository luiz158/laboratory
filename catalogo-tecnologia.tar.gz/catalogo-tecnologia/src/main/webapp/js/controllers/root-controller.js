'use strict';

/* Controllers */
var controllers = angular.module('catalogo.controllers');

controllers.controller('DashboardCtrl',
		function DashboardCtrl($scope) {

			
		});
