package br.gov.serpro.catalogo.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("api")
public class RESTApplication extends Application {

}
