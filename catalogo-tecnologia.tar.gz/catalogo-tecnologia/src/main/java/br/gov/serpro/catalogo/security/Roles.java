package br.gov.serpro.catalogo.security;

public interface Roles {
	
	static final String ADMINISTRADOR = "ADMINISTRADOR";
	static final String ANALISE = "ANALISE";

}
