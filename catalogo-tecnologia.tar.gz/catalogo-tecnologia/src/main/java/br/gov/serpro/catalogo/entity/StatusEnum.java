package br.gov.serpro.catalogo.entity;


public enum StatusEnum {
	EXCLUIDO, ATIVO;		
}
