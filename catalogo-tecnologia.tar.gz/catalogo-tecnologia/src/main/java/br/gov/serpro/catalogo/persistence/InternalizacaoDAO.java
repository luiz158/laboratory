package br.gov.serpro.catalogo.persistence;

import br.gov.frameworkdemoiselle.stereotype.PersistenceController;
import br.gov.frameworkdemoiselle.template.JPACrud;
import br.gov.serpro.catalogo.entity.Internalizacao;

@PersistenceController
public class InternalizacaoDAO extends JPACrud<Internalizacao, Long> {
	
	private static final long serialVersionUID = 1L;		
	
	
	
	
}
